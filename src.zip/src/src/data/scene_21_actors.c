#pragma bank 255

// Scene: Scene 21
// Actors

#include "gbs_types.h"
#include "data/sprite_usurper_sprites.h"
#include "data/actor_4_interact.h"
#include "data/sprite_usurper_sprites.h"
#include "data/actor_5_interact.h"

BANKREF(scene_21_actors)

const struct actor_t scene_21_actors[] = {
    {
        // Actor 1,
        .pos = {
            .x = 152 * 16,
            .y = 88 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_LEFT,
        .sprite = TO_FAR_PTR_T(sprite_usurper_sprites),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(actor_4_interact),
        .reserve_tiles = 0
    },
    {
        // Actor 2,
        .pos = {
            .x = 176 * 16,
            .y = 88 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_usurper_sprites),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(actor_5_interact),
        .reserve_tiles = 0
    }
};
