#pragma bank 255

// Scene: Scene 21
// Sprites

#include "gbs_types.h"
#include "data/sprite_usurper_sprites.h"

BANKREF(scene_21_sprites)

const far_ptr_t scene_21_sprites[] = {
    TO_FAR_PTR_T(sprite_usurper_sprites)
};
