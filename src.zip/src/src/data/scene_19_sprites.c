#pragma bank 255

// Scene: Scene 19
// Sprites

#include "gbs_types.h"
#include "data/sprite_player.h"

BANKREF(scene_19_sprites)

const far_ptr_t scene_19_sprites[] = {
    TO_FAR_PTR_T(sprite_player)
};
