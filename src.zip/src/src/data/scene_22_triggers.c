#pragma bank 255

// Scene: Scene 22
// Triggers

#include "gbs_types.h"
#include "data/trigger_43_interact.h"

BANKREF(scene_22_triggers)

const struct trigger_t scene_22_triggers[] = {
    {
        // Trigger 1,
        .x = 9,
        .y = 15,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_43_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
