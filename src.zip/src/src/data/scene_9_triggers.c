#pragma bank 255

// Scene: Scene 9
// Triggers

#include "gbs_types.h"
#include "data/trigger_9_interact.h"
#include "data/trigger_13_interact.h"

BANKREF(scene_9_triggers)

const struct trigger_t scene_9_triggers[] = {
    {
        // Trigger 1,
        .x = 56,
        .y = 26,
        .width = 4,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_9_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 6,
        .y = 0,
        .width = 6,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_13_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
