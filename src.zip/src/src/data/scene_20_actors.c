#pragma bank 255

// Scene: Scene 20
// Actors

#include "gbs_types.h"
#include "data/sprite_npc001.h"
#include "data/actor_3_interact.h"

BANKREF(scene_20_actors)

const struct actor_t scene_20_actors[] = {
    {
        // Actor 1,
        .pos = {
            .x = 104 * 16,
            .y = 88 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = -8
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_npc001),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(actor_3_interact),
        .reserve_tiles = 0
    }
};
