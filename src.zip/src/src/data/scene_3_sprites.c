#pragma bank 255

// Scene: Scene 3
// Sprites

#include "gbs_types.h"
#include "data/sprite_npc003.h"

BANKREF(scene_3_sprites)

const far_ptr_t scene_3_sprites[] = {
    TO_FAR_PTR_T(sprite_npc003)
};
