#pragma bank 255

// Background: mahhtp

#include "gbs_types.h"
#include "data/bg_mahhtp_tileset.h"
#include "data/bg_mahhtp_tilemap.h"

BANKREF(bg_mahhtp)

const struct background_t bg_mahhtp = {
    .width = 64,
    .height = 32,
    .tileset = TO_FAR_PTR_T(bg_mahhtp_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_mahhtp_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
