#pragma bank 255

// Scene: Scene 8
// Sprites

#include "gbs_types.h"
#include "data/sprite_npc002.h"

BANKREF(scene_8_sprites)

const far_ptr_t scene_8_sprites[] = {
    TO_FAR_PTR_T(sprite_npc002)
};
