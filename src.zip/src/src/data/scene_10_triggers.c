#pragma bank 255

// Scene: Scene 10
// Triggers

#include "gbs_types.h"
#include "data/trigger_10_interact.h"
#include "data/trigger_12_interact.h"

BANKREF(scene_10_triggers)

const struct trigger_t scene_10_triggers[] = {
    {
        // Trigger 1,
        .x = 26,
        .y = 13,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_10_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 23,
        .y = 0,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_12_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
