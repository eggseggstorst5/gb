#pragma bank 255

// Background: maaaapp

#include "gbs_types.h"
#include "data/bg_maaaapp_tileset.h"
#include "data/bg_maaaapp_tilemap.h"

BANKREF(bg_maaaapp)

const struct background_t bg_maaaapp = {
    .width = 32,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_maaaapp_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_maaaapp_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
