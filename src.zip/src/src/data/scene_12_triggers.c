#pragma bank 255

// Scene: Scene 12
// Triggers

#include "gbs_types.h"
#include "data/trigger_15_interact.h"
#include "data/trigger_16_interact.h"
#include "data/trigger_17_interact.h"
#include "data/trigger_18_interact.h"
#include "data/trigger_22_interact.h"

BANKREF(scene_12_triggers)

const struct trigger_t scene_12_triggers[] = {
    {
        // Trigger 1,
        .x = 0,
        .y = 42,
        .width = 1,
        .height = 13,
        .script = TO_FAR_PTR_T(trigger_15_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 28,
        .y = 39,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_16_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 16,
        .y = 34,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_17_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 7,
        .y = 22,
        .width = 1,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_18_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 5,
        .x = 6,
        .y = 18,
        .width = 6,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_22_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
