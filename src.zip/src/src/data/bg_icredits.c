#pragma bank 255

// Background: icredits

#include "gbs_types.h"
#include "data/bg_icredits_tileset.h"
#include "data/bg_icredits_tilemap.h"

BANKREF(bg_icredits)

const struct background_t bg_icredits = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_icredits_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_icredits_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
