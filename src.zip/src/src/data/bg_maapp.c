#pragma bank 255

// Background: maapp

#include "gbs_types.h"
#include "data/bg_maapp_tileset.h"
#include "data/bg_maapp_tilemap.h"

BANKREF(bg_maapp)

const struct background_t bg_maapp = {
    .width = 20,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_maapp_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_maapp_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
