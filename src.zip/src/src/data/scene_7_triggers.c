#pragma bank 255

// Scene: Scene 7
// Triggers

#include "gbs_types.h"
#include "data/trigger_1_interact.h"
#include "data/trigger_5_interact.h"
#include "data/trigger_38_interact.h"
#include "data/trigger_39_interact.h"
#include "data/trigger_41_interact.h"

BANKREF(scene_7_triggers)

const struct trigger_t scene_7_triggers[] = {
    {
        // Trigger 1,
        .x = 31,
        .y = 2,
        .width = 1,
        .height = 28,
        .script = TO_FAR_PTR_T(trigger_1_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 0,
        .y = 18,
        .width = 1,
        .height = 4,
        .script = TO_FAR_PTR_T(trigger_5_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 7,
        .y = 12,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_38_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 14,
        .y = 26,
        .width = 4,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_39_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 5,
        .x = 22,
        .y = 12,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_41_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
