#pragma bank 255

// Scene: Scene 19
// Actors

#include "gbs_types.h"
#include "data/sprite_player.h"
#include "data/actor_2_interact.h"

BANKREF(scene_19_actors)

const struct actor_t scene_19_actors[] = {
    {
        // Actor 1,
        .pos = {
            .x = 104 * 16,
            .y = 88 * 16
        },
        .bounds = {
            .left = 0,
            .bottom = 7,
            .right = 15,
            .top = 0
        },
        .dir = DIR_DOWN,
        .sprite = TO_FAR_PTR_T(sprite_player),
        .move_speed = 16,
        .anim_tick = 15,
        .pinned = FALSE,
        .persistent = FALSE,
        .collision_group = COLLISION_GROUP_NONE,
        .collision_enabled = TRUE,
        .script = TO_FAR_PTR_T(actor_2_interact),
        .reserve_tiles = 0
    }
};
