#pragma bank 255

// Background: mforeststartp

#include "gbs_types.h"
#include "data/bg_mforeststartp_tileset.h"
#include "data/bg_mforeststartp_tilemap.h"

BANKREF(bg_mforeststartp)

const struct background_t bg_mforeststartp = {
    .width = 32,
    .height = 64,
    .tileset = TO_FAR_PTR_T(bg_mforeststartp_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_mforeststartp_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
