#pragma bank 255

// Background: mapppp

#include "gbs_types.h"
#include "data/bg_mapppp_tileset.h"
#include "data/bg_mapppp_tilemap.h"

BANKREF(bg_mapppp)

const struct background_t bg_mapppp = {
    .width = 32,
    .height = 32,
    .tileset = TO_FAR_PTR_T(bg_mapppp_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_mapppp_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
