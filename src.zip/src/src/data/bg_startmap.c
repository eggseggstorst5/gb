#pragma bank 255

// Background: startmap

#include "gbs_types.h"
#include "data/bg_startmap_tileset.h"
#include "data/bg_startmap_tilemap.h"

BANKREF(bg_startmap)

const struct background_t bg_startmap = {
    .width = 20,
    .height = 64,
    .tileset = TO_FAR_PTR_T(bg_startmap_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_startmap_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
