#pragma bank 255

// Scene: Scene 4
// Sprites

#include "gbs_types.h"
#include "data/sprite_torch.h"
#include "data/sprite_fire.h"

BANKREF(scene_4_sprites)

const far_ptr_t scene_4_sprites[] = {
    TO_FAR_PTR_T(sprite_torch),
    TO_FAR_PTR_T(sprite_fire)
};
