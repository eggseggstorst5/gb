#pragma bank 255

// Scene: Scene 8
// Triggers

#include "gbs_types.h"
#include "data/trigger_2_interact.h"
#include "data/trigger_4_interact.h"
#include "data/trigger_8_interact.h"
#include "data/trigger_14_interact.h"
#include "data/trigger_31_interact.h"

BANKREF(scene_8_triggers)

const struct trigger_t scene_8_triggers[] = {
    {
        // Trigger 1,
        .x = 0,
        .y = 2,
        .width = 1,
        .height = 28,
        .script = TO_FAR_PTR_T(trigger_2_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 5,
        .y = 26,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_4_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 3,
        .x = 12,
        .y = 31,
        .width = 6,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_8_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 4,
        .x = 31,
        .y = 11,
        .width = 1,
        .height = 9,
        .script = TO_FAR_PTR_T(trigger_14_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 5,
        .x = 12,
        .y = 0,
        .width = 6,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_31_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
