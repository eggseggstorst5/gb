#pragma bank 255

// Background: ma   p

#include "gbs_types.h"
#include "data/bg_ma_p_0_tileset.h"
#include "data/bg_ma_p_0_tilemap.h"

BANKREF(bg_ma_p_0)

const struct background_t bg_ma_p_0 = {
    .width = 32,
    .height = 32,
    .tileset = TO_FAR_PTR_T(bg_ma_p_0_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_ma_p_0_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
