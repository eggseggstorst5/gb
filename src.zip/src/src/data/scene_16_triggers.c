#pragma bank 255

// Scene: Scene 16
// Triggers

#include "gbs_types.h"
#include "data/trigger_27_interact.h"
#include "data/trigger_29_interact.h"

BANKREF(scene_16_triggers)

const struct trigger_t scene_16_triggers[] = {
    {
        // Trigger 1,
        .x = 25,
        .y = 8,
        .width = 2,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_27_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 11,
        .y = 0,
        .width = 1,
        .height = 1,
        .script = TO_FAR_PTR_T(trigger_29_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
