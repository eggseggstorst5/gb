#pragma bank 255

// Background: cave3

#include "gbs_types.h"
#include "data/bg_cave3_tileset.h"
#include "data/bg_cave3_tilemap.h"

BANKREF(bg_cave3)

const struct background_t bg_cave3 = {
    .width = 64,
    .height = 32,
    .tileset = TO_FAR_PTR_T(bg_cave3_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_cave3_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
