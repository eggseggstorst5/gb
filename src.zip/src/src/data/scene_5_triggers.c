#pragma bank 255

// Scene: Scene 5
// Triggers

#include "gbs_types.h"
#include "data/trigger_0_interact.h"
#include "data/trigger_44_interact.h"

BANKREF(scene_5_triggers)

const struct trigger_t scene_5_triggers[] = {
    {
        // Trigger 1,
        .x = 19,
        .y = 50,
        .width = 1,
        .height = 4,
        .script = TO_FAR_PTR_T(trigger_0_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    },
    {
        // Trigger 2,
        .x = 9,
        .y = 5,
        .width = 2,
        .height = 2,
        .script = TO_FAR_PTR_T(trigger_44_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
