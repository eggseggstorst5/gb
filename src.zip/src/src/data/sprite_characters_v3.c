#pragma bank 255
// SpriteSheet: Characters_V3

#include "gbs_types.h"
#include "data/sprite_characters_v3_tileset.h"


BANKREF(sprite_characters_v3)

#define SPRITE_0_STATE_DEFAULT 0
#define SPRITE_0_STATE_2D 8

const metasprite_t sprite_characters_v3_metasprite_0[]  = {
    { 0, 8, 8, 0 }, { 0, -8, 10, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_1[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 2, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_2[]  = {
    { 0, 8, 4, 0 }, { 0, -8, 6, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_3[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 2, 32 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_4[]  = {
    { 0, 8, 26, 0 }, { 0, -8, 28, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_5[]  = {
    { 0, 8, 30, 0 }, { 0, -8, 32, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_6[]  = {
    { 0, 8, 0, 0 }, { 0, -8, 12, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_7[]  = {
    { 0, 8, 14, 0 }, { 0, -8, 16, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_8[]  = {
    { 0, 8, 18, 0 }, { 0, -8, 20, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_9[]  = {
    { 0, 8, 22, 0 }, { 0, -8, 24, 0 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_10[]  = {
    { 0, 0, 0, 32 }, { 0, 8, 12, 32 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_11[]  = {
    { 0, 0, 14, 32 }, { 0, 8, 16, 32 },
    {metasprite_end}
};

const metasprite_t sprite_characters_v3_metasprite_12[]  = {
    {metasprite_end}
};

const metasprite_t * const sprite_characters_v3_metasprites[] = {
    sprite_characters_v3_metasprite_0,
    sprite_characters_v3_metasprite_1,
    sprite_characters_v3_metasprite_2,
    sprite_characters_v3_metasprite_3,
    sprite_characters_v3_metasprite_4,
    sprite_characters_v3_metasprite_5,
    sprite_characters_v3_metasprite_6,
    sprite_characters_v3_metasprite_7,
    sprite_characters_v3_metasprite_8,
    sprite_characters_v3_metasprite_9,
    sprite_characters_v3_metasprite_10,
    sprite_characters_v3_metasprite_11,
    sprite_characters_v3_metasprite_12
};

const struct animation_t sprite_characters_v3_animations[] = {
    {
        .start = 0,
        .end = 0
    },
    {
        .start = 1,
        .end = 1
    },
    {
        .start = 2,
        .end = 2
    },
    {
        .start = 3,
        .end = 3
    },
    {
        .start = 4,
        .end = 5
    },
    {
        .start = 6,
        .end = 7
    },
    {
        .start = 8,
        .end = 9
    },
    {
        .start = 10,
        .end = 11
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    },
    {
        .start = 12,
        .end = 12
    }
};

const UWORD sprite_characters_v3_animations_lookup[] = {
    SPRITE_0_STATE_DEFAULT,
    SPRITE_0_STATE_2D
};

const struct spritesheet_t sprite_characters_v3 = {
    .n_metasprites = 13,
    .emote_origin = {
        .x = 0,
        .y = -16
    },
    .metasprites = sprite_characters_v3_metasprites,
    .animations = sprite_characters_v3_animations,
    .animations_lookup = sprite_characters_v3_animations_lookup,
    .bounds = {
        .left = 0,
        .bottom = 7,
        .right = 15,
        .top = -8
    },
    .tileset = TO_FAR_PTR_T(sprite_characters_v3_tileset),
    .cgb_tileset = { NULL, NULL }
};
