#pragma bank 255

// Scene: Scene 14
// Triggers

#include "gbs_types.h"
#include "data/trigger_26_interact.h"

BANKREF(scene_14_triggers)

const struct trigger_t scene_14_triggers[] = {
    {
        // Trigger 1,
        .x = 63,
        .y = 17,
        .width = 1,
        .height = 5,
        .script = TO_FAR_PTR_T(trigger_26_interact),
        .script_flags = TRIGGER_HAS_ENTER_SCRIPT
    }
};
