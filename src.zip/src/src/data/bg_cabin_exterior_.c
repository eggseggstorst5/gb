#pragma bank 255

// Background: Cabin(Exterior)

#include "gbs_types.h"
#include "data/bg_cabin_exterior__tileset.h"
#include "data/bg_cabin_exterior__tilemap.h"

BANKREF(bg_cabin_exterior_)

const struct background_t bg_cabin_exterior_ = {
    .width = 32,
    .height = 18,
    .tileset = TO_FAR_PTR_T(bg_cabin_exterior__tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_cabin_exterior__tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
