#pragma bank 255

// Scene: Scene 17
// Sprites

#include "gbs_types.h"
#include "data/sprite_skeleton.h"

BANKREF(scene_17_sprites)

const far_ptr_t scene_17_sprites[] = {
    TO_FAR_PTR_T(sprite_skeleton)
};
