#pragma bank 255

// Background: inside_example

#include "gbs_types.h"
#include "data/bg_inside_example_tileset.h"
#include "data/bg_inside_example_tilemap.h"

BANKREF(bg_inside_example)

const struct background_t bg_inside_example = {
    .width = 22,
    .height = 20,
    .tileset = TO_FAR_PTR_T(bg_inside_example_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_inside_example_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
