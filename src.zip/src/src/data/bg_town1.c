#pragma bank 255

// Background: town1

#include "gbs_types.h"
#include "data/bg_town1_tileset.h"
#include "data/bg_town1_tilemap.h"

BANKREF(bg_town1)

const struct background_t bg_town1 = {
    .width = 32,
    .height = 32,
    .tileset = TO_FAR_PTR_T(bg_town1_tileset),
    .cgb_tileset = { NULL, NULL },
    .tilemap = TO_FAR_PTR_T(bg_town1_tilemap),
    .cgb_tilemap_attr = { NULL, NULL }
};
