#pragma bank 255

// Scene: Scene 20

#include "gbs_types.h"
#include "data/bg_maapp.h"
#include "data/scene_20_collisions.h"
#include "data/palette_0.h"
#include "data/palette_1.h"
#include "data/sprite_characters_v3.h"
#include "data/scene_20_actors.h"
#include "data/scene_20_triggers.h"
#include "data/scene_20_sprites.h"
#include "data/scene_20_init.h"

BANKREF(scene_20)

const struct scene_t scene_20 = {
    .width = 20,
    .height = 18,
    .type = SCENE_TYPE_TOPDOWN,
    .background = TO_FAR_PTR_T(bg_maapp),
    .collisions = TO_FAR_PTR_T(scene_20_collisions),
    .parallax_rows = {
        PARALLAX_STEP(0,0,0)
    },
    .palette = TO_FAR_PTR_T(palette_0),
    .sprite_palette = TO_FAR_PTR_T(palette_1),
    .reserve_tiles = 0,
    .player_sprite = TO_FAR_PTR_T(sprite_characters_v3),
    .n_actors = 1,
    .n_triggers = 1,
    .n_sprites = 1,
    .n_projectiles = 0,
    .actors = TO_FAR_PTR_T(scene_20_actors),
    .triggers = TO_FAR_PTR_T(scene_20_triggers),
    .sprites = TO_FAR_PTR_T(scene_20_sprites),
    .script_init = TO_FAR_PTR_T(scene_20_init)
};
