#pragma bank 255

// Scene: Scene 15

#include "gbs_types.h"
#include "data/bg_inside_example.h"
#include "data/scene_15_collisions.h"
#include "data/palette_0.h"
#include "data/palette_1.h"
#include "data/sprite_characters_v3.h"
#include "data/scene_15_triggers.h"
#include "data/scene_15_init.h"

BANKREF(scene_15)

const struct scene_t scene_15 = {
    .width = 22,
    .height = 20,
    .type = SCENE_TYPE_TOPDOWN,
    .background = TO_FAR_PTR_T(bg_inside_example),
    .collisions = TO_FAR_PTR_T(scene_15_collisions),
    .parallax_rows = {
        PARALLAX_STEP(0,0,0)
    },
    .palette = TO_FAR_PTR_T(palette_0),
    .sprite_palette = TO_FAR_PTR_T(palette_1),
    .reserve_tiles = 0,
    .player_sprite = TO_FAR_PTR_T(sprite_characters_v3),
    .n_actors = 0,
    .n_triggers = 2,
    .n_sprites = 0,
    .n_projectiles = 0,
    .triggers = TO_FAR_PTR_T(scene_15_triggers),
    .script_init = TO_FAR_PTR_T(scene_15_init)
};
