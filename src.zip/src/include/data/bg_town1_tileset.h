#ifndef BG_TOWN1_TILESET_H
#define BG_TOWN1_TILESET_H

// Tileset: bg_town1_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_town1_tileset)
extern const struct tileset_t bg_town1_tileset;

#endif
