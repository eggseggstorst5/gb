#ifndef SCENE_17_INIT_H
#define SCENE_17_INIT_H

// Script scene_17_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_17_init)
extern const unsigned char scene_17_init[];

#endif
