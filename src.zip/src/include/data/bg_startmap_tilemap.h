#ifndef BG_STARTMAP_TILEMAP_H
#define BG_STARTMAP_TILEMAP_H

// Tilemap bg_startmap_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_startmap_tilemap)
extern const unsigned char bg_startmap_tilemap[];

#endif
