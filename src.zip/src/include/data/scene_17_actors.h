#ifndef SCENE_17_ACTORS_H
#define SCENE_17_ACTORS_H

// Scene: Scene 17
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_17_actors)
extern const struct actor_t scene_17_actors[];

#endif
