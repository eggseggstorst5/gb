#ifndef SCENE_23_H
#define SCENE_23_H

// Scene: Scene 23

#include "gbs_types.h"

BANKREF_EXTERN(scene_23)
extern const struct scene_t scene_23;

#endif
