#ifndef BG_UNTITLED_TILEMAP_H
#define BG_UNTITLED_TILEMAP_H

// Tilemap bg_untitled_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_untitled_tilemap)
extern const unsigned char bg_untitled_tilemap[];

#endif
