#ifndef SCENE_20_COLLISIONS_H
#define SCENE_20_COLLISIONS_H

// Scene: Scene 20
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_20_collisions)
extern const unsigned char scene_20_collisions[];

#endif
