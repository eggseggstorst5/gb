#ifndef FONT_GBS_MONO_H
#define FONT_GBS_MONO_H

// Font gbs-mono.png

#include "gbs_types.h"

BANKREF_EXTERN(font_gbs_mono)
extern const unsigned char font_gbs_mono[];

#endif
