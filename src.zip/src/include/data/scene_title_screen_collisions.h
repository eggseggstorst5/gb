#ifndef SCENE_TITLE_SCREEN_COLLISIONS_H
#define SCENE_TITLE_SCREEN_COLLISIONS_H

// Scene: Title Screen
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_title_screen_collisions)
extern const unsigned char scene_title_screen_collisions[];

#endif
