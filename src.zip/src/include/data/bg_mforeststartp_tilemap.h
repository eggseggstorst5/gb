#ifndef BG_MFORESTSTARTP_TILEMAP_H
#define BG_MFORESTSTARTP_TILEMAP_H

// Tilemap bg_mforeststartp_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_mforeststartp_tilemap)
extern const unsigned char bg_mforeststartp_tilemap[];

#endif
