#ifndef BG_MAAPP_TILESET_H
#define BG_MAAPP_TILESET_H

// Tileset: bg_maapp_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_maapp_tileset)
extern const struct tileset_t bg_maapp_tileset;

#endif
