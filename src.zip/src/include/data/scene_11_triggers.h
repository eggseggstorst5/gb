#ifndef SCENE_11_TRIGGERS_H
#define SCENE_11_TRIGGERS_H

// Scene: Scene 11
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_11_triggers)
extern const struct trigger_t scene_11_triggers[];

#endif
