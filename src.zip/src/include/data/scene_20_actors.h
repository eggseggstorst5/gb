#ifndef SCENE_20_ACTORS_H
#define SCENE_20_ACTORS_H

// Scene: Scene 20
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_20_actors)
extern const struct actor_t scene_20_actors[];

#endif
