#ifndef SCENE_21_INIT_H
#define SCENE_21_INIT_H

// Script scene_21_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_21_init)
extern const unsigned char scene_21_init[];

#endif
