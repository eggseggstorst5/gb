#ifndef SPRITE_NPC003_H
#define SPRITE_NPC003_H

// SpriteSheet: npc003

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc003)
extern const struct spritesheet_t sprite_npc003;

#endif
