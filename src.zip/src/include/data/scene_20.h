#ifndef SCENE_20_H
#define SCENE_20_H

// Scene: Scene 20

#include "gbs_types.h"

BANKREF_EXTERN(scene_20)
extern const struct scene_t scene_20;

#endif
