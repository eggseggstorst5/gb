#ifndef BG_MA_P_0_H
#define BG_MA_P_0_H

// Background: ma   p

#include "gbs_types.h"

BANKREF_EXTERN(bg_ma_p_0)
extern const struct background_t bg_ma_p_0;

#endif
