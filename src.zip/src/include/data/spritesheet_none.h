#ifndef SPRITESHEET_NONE_H
#define SPRITESHEET_NONE_H

// SpriteSheet: None

#include "gbs_types.h"

extern const void __bank_spritesheet_none;
extern const struct spritesheet_t spritesheet_none;

#endif
