#ifndef SCENE_CAVE_COLLISIONS_H
#define SCENE_CAVE_COLLISIONS_H

// Scene: Cave
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_cave_collisions)
extern const unsigned char scene_cave_collisions[];

#endif
