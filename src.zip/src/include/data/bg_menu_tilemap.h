#ifndef BG_MENU_TILEMAP_H
#define BG_MENU_TILEMAP_H

// Tilemap bg_menu_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_menu_tilemap)
extern const unsigned char bg_menu_tilemap[];

#endif
