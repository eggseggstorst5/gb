#ifndef SCENE_15_COLLISIONS_H
#define SCENE_15_COLLISIONS_H

// Scene: Scene 15
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_15_collisions)
extern const unsigned char scene_15_collisions[];

#endif
