#ifndef SCENE_19_INIT_H
#define SCENE_19_INIT_H

// Script scene_19_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_19_init)
extern const unsigned char scene_19_init[];

#endif
