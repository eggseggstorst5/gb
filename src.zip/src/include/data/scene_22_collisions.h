#ifndef SCENE_22_COLLISIONS_H
#define SCENE_22_COLLISIONS_H

// Scene: Scene 22
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_22_collisions)
extern const unsigned char scene_22_collisions[];

#endif
