#ifndef SCENE_21_SPRITES_H
#define SCENE_21_SPRITES_H

// Scene: Scene 21
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_21_sprites)
extern const far_ptr_t scene_21_sprites[];

#endif
