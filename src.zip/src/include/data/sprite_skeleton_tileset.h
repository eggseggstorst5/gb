#ifndef SPRITE_SKELETON_TILESET_H
#define SPRITE_SKELETON_TILESET_H

// Tileset: sprite_skeleton_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_skeleton_tileset)
extern const struct tileset_t sprite_skeleton_tileset;

#endif
