#ifndef BG_MAAPP_TILEMAP_H
#define BG_MAAPP_TILEMAP_H

// Tilemap bg_maapp_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_maapp_tilemap)
extern const unsigned char bg_maapp_tilemap[];

#endif
