#ifndef BG_MENU_H
#define BG_MENU_H

// Background: menu

#include "gbs_types.h"

BANKREF_EXTERN(bg_menu)
extern const struct background_t bg_menu;

#endif
