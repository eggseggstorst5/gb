#ifndef SCENE_12_TRIGGERS_H
#define SCENE_12_TRIGGERS_H

// Scene: Scene 12
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_12_triggers)
extern const struct trigger_t scene_12_triggers[];

#endif
