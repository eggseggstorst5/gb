#ifndef BG_MA_P_0_TILEMAP_H
#define BG_MA_P_0_TILEMAP_H

// Tilemap bg_ma_p_0_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_ma_p_0_tilemap)
extern const unsigned char bg_ma_p_0_tilemap[];

#endif
