#ifndef SCENE_20_INIT_H
#define SCENE_20_INIT_H

// Script scene_20_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_20_init)
extern const unsigned char scene_20_init[];

#endif
