#ifndef SCENE_13_TRIGGERS_H
#define SCENE_13_TRIGGERS_H

// Scene: Scene 13
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_13_triggers)
extern const struct trigger_t scene_13_triggers[];

#endif
