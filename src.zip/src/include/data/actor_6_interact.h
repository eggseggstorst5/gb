#ifndef ACTOR_6_INTERACT_H
#define ACTOR_6_INTERACT_H

// Script actor_6_interact

#include "gbs_types.h"

BANKREF_EXTERN(actor_6_interact)
extern const unsigned char actor_6_interact[];

#endif
