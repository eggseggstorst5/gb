#ifndef SCENE_20_TRIGGERS_H
#define SCENE_20_TRIGGERS_H

// Scene: Scene 20
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_20_triggers)
extern const struct trigger_t scene_20_triggers[];

#endif
