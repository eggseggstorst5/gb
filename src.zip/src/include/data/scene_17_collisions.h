#ifndef SCENE_17_COLLISIONS_H
#define SCENE_17_COLLISIONS_H

// Scene: Scene 17
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_17_collisions)
extern const unsigned char scene_17_collisions[];

#endif
