#ifndef SPRITE_SAGE_H
#define SPRITE_SAGE_H

// SpriteSheet: sage

#include "gbs_types.h"

BANKREF_EXTERN(sprite_sage)
extern const struct spritesheet_t sprite_sage;

#endif
