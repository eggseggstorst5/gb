#ifndef SCENE_3_COLLISIONS_H
#define SCENE_3_COLLISIONS_H

// Scene: Scene 3
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_collisions)
extern const unsigned char scene_3_collisions[];

#endif
