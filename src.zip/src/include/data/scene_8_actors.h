#ifndef SCENE_8_ACTORS_H
#define SCENE_8_ACTORS_H

// Scene: Scene 8
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_8_actors)
extern const struct actor_t scene_8_actors[];

#endif
