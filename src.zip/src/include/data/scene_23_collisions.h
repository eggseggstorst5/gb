#ifndef SCENE_23_COLLISIONS_H
#define SCENE_23_COLLISIONS_H

// Scene: Scene 23
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_23_collisions)
extern const unsigned char scene_23_collisions[];

#endif
