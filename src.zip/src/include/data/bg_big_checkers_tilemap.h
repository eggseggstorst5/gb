#ifndef BG_BIG_CHECKERS_TILEMAP_H
#define BG_BIG_CHECKERS_TILEMAP_H

// Tilemap bg_big_checkers_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_big_checkers_tilemap)
extern const unsigned char bg_big_checkers_tilemap[];

#endif
