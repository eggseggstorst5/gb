#ifndef SCENE_4_ACTORS_H
#define SCENE_4_ACTORS_H

// Scene: Scene 4
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_4_actors)
extern const struct actor_t scene_4_actors[];

#endif
