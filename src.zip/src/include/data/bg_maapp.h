#ifndef BG_MAAPP_H
#define BG_MAAPP_H

// Background: maapp

#include "gbs_types.h"

BANKREF_EXTERN(bg_maapp)
extern const struct background_t bg_maapp;

#endif
