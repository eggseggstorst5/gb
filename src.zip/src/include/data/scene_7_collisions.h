#ifndef SCENE_7_COLLISIONS_H
#define SCENE_7_COLLISIONS_H

// Scene: Scene 7
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_7_collisions)
extern const unsigned char scene_7_collisions[];

#endif
