#ifndef BG_INSIDE_EXAMPLE_TILESET_H
#define BG_INSIDE_EXAMPLE_TILESET_H

// Tileset: bg_inside_example_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_inside_example_tileset)
extern const struct tileset_t bg_inside_example_tileset;

#endif
