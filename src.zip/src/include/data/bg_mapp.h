#ifndef BG_MAPP_H
#define BG_MAPP_H

// Background: mapp

#include "gbs_types.h"

BANKREF_EXTERN(bg_mapp)
extern const struct background_t bg_mapp;

#endif
