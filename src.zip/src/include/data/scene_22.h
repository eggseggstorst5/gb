#ifndef SCENE_22_H
#define SCENE_22_H

// Scene: Scene 22

#include "gbs_types.h"

BANKREF_EXTERN(scene_22)
extern const struct scene_t scene_22;

#endif
