#ifndef SCENE_8_INIT_H
#define SCENE_8_INIT_H

// Script scene_8_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_8_init)
extern const unsigned char scene_8_init[];

#endif
