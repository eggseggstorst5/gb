#ifndef TRIGGER_30_INTERACT_H
#define TRIGGER_30_INTERACT_H

// Script trigger_30_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_30_interact)
extern const unsigned char trigger_30_interact[];

#endif
