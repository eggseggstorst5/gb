#ifndef SCENE_12_INIT_H
#define SCENE_12_INIT_H

// Script scene_12_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_12_init)
extern const unsigned char scene_12_init[];

#endif
