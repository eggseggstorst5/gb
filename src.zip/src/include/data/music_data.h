#ifndef MUSIC_DATA_H
#define MUSIC_DATA_H

extern const void __bank_song_bs_free_menu_Data;
extern const void song_bs_free_menu_Data;
extern const void __bank_song_rulz_gonaspace_Data;
extern const void song_rulz_gonaspace_Data;

#endif
