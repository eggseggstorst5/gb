#ifndef BG_MAPPPP_TILEMAP_H
#define BG_MAPPPP_TILEMAP_H

// Tilemap bg_mapppp_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_mapppp_tilemap)
extern const unsigned char bg_mapppp_tilemap[];

#endif
