#ifndef SCENE_10_COLLISIONS_H
#define SCENE_10_COLLISIONS_H

// Scene: Scene 10
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_10_collisions)
extern const unsigned char scene_10_collisions[];

#endif
