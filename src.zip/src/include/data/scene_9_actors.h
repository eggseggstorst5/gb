#ifndef SCENE_9_ACTORS_H
#define SCENE_9_ACTORS_H

// Scene: Scene 9
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_9_actors)
extern const struct actor_t scene_9_actors[];

#endif
