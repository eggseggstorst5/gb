#ifndef SPRITE_CHEST_2_H
#define SPRITE_CHEST_2_H

// SpriteSheet: Chest_2

#include "gbs_types.h"

BANKREF_EXTERN(sprite_chest_2)
extern const struct spritesheet_t sprite_chest_2;

#endif
