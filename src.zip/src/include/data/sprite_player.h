#ifndef SPRITE_PLAYER_H
#define SPRITE_PLAYER_H

// SpriteSheet: player

#include "gbs_types.h"

BANKREF_EXTERN(sprite_player)
extern const struct spritesheet_t sprite_player;

#endif
