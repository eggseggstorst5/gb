#ifndef SCENE_18_H
#define SCENE_18_H

// Scene: Scene 18

#include "gbs_types.h"

BANKREF_EXTERN(scene_18)
extern const struct scene_t scene_18;

#endif
