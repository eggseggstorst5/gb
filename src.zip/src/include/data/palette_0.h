#ifndef PALETTE_0_H
#define PALETTE_0_H

// Palette: 0

#include "gbs_types.h"

BANKREF_EXTERN(palette_0)
extern const struct palette_t palette_0;

#endif
