#ifndef SCENE_6_INIT_H
#define SCENE_6_INIT_H

// Script scene_6_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_6_init)
extern const unsigned char scene_6_init[];

#endif
