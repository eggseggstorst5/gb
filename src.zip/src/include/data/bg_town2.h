#ifndef BG_TOWN2_H
#define BG_TOWN2_H

// Background: town2

#include "gbs_types.h"

BANKREF_EXTERN(bg_town2)
extern const struct background_t bg_town2;

#endif
