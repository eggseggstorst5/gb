#ifndef BG_HOUSE_H
#define BG_HOUSE_H

// Background: house

#include "gbs_types.h"

BANKREF_EXTERN(bg_house)
extern const struct background_t bg_house;

#endif
