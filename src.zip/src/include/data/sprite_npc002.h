#ifndef SPRITE_NPC002_H
#define SPRITE_NPC002_H

// SpriteSheet: npc002

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc002)
extern const struct spritesheet_t sprite_npc002;

#endif
