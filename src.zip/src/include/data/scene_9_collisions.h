#ifndef SCENE_9_COLLISIONS_H
#define SCENE_9_COLLISIONS_H

// Scene: Scene 9
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_9_collisions)
extern const unsigned char scene_9_collisions[];

#endif
