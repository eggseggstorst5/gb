#ifndef SCENE_13_INIT_H
#define SCENE_13_INIT_H

// Script scene_13_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_13_init)
extern const unsigned char scene_13_init[];

#endif
