#ifndef SCENE_11_H
#define SCENE_11_H

// Scene: Scene 11

#include "gbs_types.h"

BANKREF_EXTERN(scene_11)
extern const struct scene_t scene_11;

#endif
