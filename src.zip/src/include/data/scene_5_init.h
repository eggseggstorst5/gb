#ifndef SCENE_5_INIT_H
#define SCENE_5_INIT_H

// Script scene_5_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_5_init)
extern const unsigned char scene_5_init[];

#endif
