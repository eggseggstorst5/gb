#ifndef BG_MAPPPP_H
#define BG_MAPPPP_H

// Background: mapppp

#include "gbs_types.h"

BANKREF_EXTERN(bg_mapppp)
extern const struct background_t bg_mapppp;

#endif
