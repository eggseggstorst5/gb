#ifndef BG_LOGO_TILEMAP_H
#define BG_LOGO_TILEMAP_H

// Tilemap bg_logo_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_logo_tilemap)
extern const unsigned char bg_logo_tilemap[];

#endif
