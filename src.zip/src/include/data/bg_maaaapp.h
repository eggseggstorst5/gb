#ifndef BG_MAAAAPP_H
#define BG_MAAAAPP_H

// Background: maaaapp

#include "gbs_types.h"

BANKREF_EXTERN(bg_maaaapp)
extern const struct background_t bg_maaaapp;

#endif
