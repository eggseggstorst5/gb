#ifndef SCENE_9_INIT_H
#define SCENE_9_INIT_H

// Script scene_9_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_9_init)
extern const unsigned char scene_9_init[];

#endif
