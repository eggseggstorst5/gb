#ifndef SCRIPT_INPUT_0_H
#define SCRIPT_INPUT_0_H

// Script script_input_0

#include "gbs_types.h"

BANKREF_EXTERN(script_input_0)
extern const unsigned char script_input_0[];

#endif
