#ifndef BG_MENU_TILESET_H
#define BG_MENU_TILESET_H

// Tileset: bg_menu_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_menu_tileset)
extern const struct tileset_t bg_menu_tileset;

#endif
