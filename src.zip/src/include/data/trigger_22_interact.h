#ifndef TRIGGER_22_INTERACT_H
#define TRIGGER_22_INTERACT_H

// Script trigger_22_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_22_interact)
extern const unsigned char trigger_22_interact[];

#endif
