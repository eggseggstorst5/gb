#ifndef SPRITE_CHARACTERS_V3_TILESET_H
#define SPRITE_CHARACTERS_V3_TILESET_H

// Tileset: sprite_characters_v3_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_characters_v3_tileset)
extern const struct tileset_t sprite_characters_v3_tileset;

#endif
