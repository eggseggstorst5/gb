#ifndef SCENE_4_TRIGGERS_H
#define SCENE_4_TRIGGERS_H

// Scene: Scene 4
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_4_triggers)
extern const struct trigger_t scene_4_triggers[];

#endif
