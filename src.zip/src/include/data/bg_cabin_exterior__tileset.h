#ifndef BG_CABIN_EXTERIOR__TILESET_H
#define BG_CABIN_EXTERIOR__TILESET_H

// Tileset: bg_cabin_exterior__tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_cabin_exterior__tileset)
extern const struct tileset_t bg_cabin_exterior__tileset;

#endif
