#ifndef BG_TOWN1_H
#define BG_TOWN1_H

// Background: town1

#include "gbs_types.h"

BANKREF_EXTERN(bg_town1)
extern const struct background_t bg_town1;

#endif
