#ifndef BG_UNTITLED_TILESET_H
#define BG_UNTITLED_TILESET_H

// Tileset: bg_untitled_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_untitled_tileset)
extern const struct tileset_t bg_untitled_tileset;

#endif
