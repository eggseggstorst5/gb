#ifndef TRIGGER_38_INTERACT_H
#define TRIGGER_38_INTERACT_H

// Script trigger_38_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_38_interact)
extern const unsigned char trigger_38_interact[];

#endif
