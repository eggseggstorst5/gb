#ifndef SCENE_23_INIT_H
#define SCENE_23_INIT_H

// Script scene_23_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_23_init)
extern const unsigned char scene_23_init[];

#endif
