#ifndef SCENE_16_COLLISIONS_H
#define SCENE_16_COLLISIONS_H

// Scene: Scene 16
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_16_collisions)
extern const unsigned char scene_16_collisions[];

#endif
