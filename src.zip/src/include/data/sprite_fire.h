#ifndef SPRITE_FIRE_H
#define SPRITE_FIRE_H

// SpriteSheet: fire

#include "gbs_types.h"

BANKREF_EXTERN(sprite_fire)
extern const struct spritesheet_t sprite_fire;

#endif
