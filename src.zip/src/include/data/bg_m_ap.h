#ifndef BG_M_AP_H
#define BG_M_AP_H

// Background: m   ap

#include "gbs_types.h"

BANKREF_EXTERN(bg_m_ap)
extern const struct background_t bg_m_ap;

#endif
