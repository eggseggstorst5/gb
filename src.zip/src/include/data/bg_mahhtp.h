#ifndef BG_MAHHTP_H
#define BG_MAHHTP_H

// Background: mahhtp

#include "gbs_types.h"

BANKREF_EXTERN(bg_mahhtp)
extern const struct background_t bg_mahhtp;

#endif
