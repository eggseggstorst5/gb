#ifndef SPRITE_CHARACTERS_V3_REWORK_H
#define SPRITE_CHARACTERS_V3_REWORK_H

// SpriteSheet: Characters_V3_Rework-export

#include "gbs_types.h"

BANKREF_EXTERN(sprite_characters_v3_rework)
extern const struct spritesheet_t sprite_characters_v3_rework;

#endif
