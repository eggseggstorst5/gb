#ifndef BG_INSIDE_EXAMPLE_TILEMAP_H
#define BG_INSIDE_EXAMPLE_TILEMAP_H

// Tilemap bg_inside_example_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_inside_example_tilemap)
extern const unsigned char bg_inside_example_tilemap[];

#endif
