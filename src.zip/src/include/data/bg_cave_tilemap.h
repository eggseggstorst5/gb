#ifndef BG_CAVE_TILEMAP_H
#define BG_CAVE_TILEMAP_H

// Tilemap bg_cave_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave_tilemap)
extern const unsigned char bg_cave_tilemap[];

#endif
