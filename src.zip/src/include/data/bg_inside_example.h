#ifndef BG_INSIDE_EXAMPLE_H
#define BG_INSIDE_EXAMPLE_H

// Background: inside_example

#include "gbs_types.h"

BANKREF_EXTERN(bg_inside_example)
extern const struct background_t bg_inside_example;

#endif
