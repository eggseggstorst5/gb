#ifndef SCENE_21_ACTORS_H
#define SCENE_21_ACTORS_H

// Scene: Scene 21
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_21_actors)
extern const struct actor_t scene_21_actors[];

#endif
