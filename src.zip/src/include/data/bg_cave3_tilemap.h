#ifndef BG_CAVE3_TILEMAP_H
#define BG_CAVE3_TILEMAP_H

// Tilemap bg_cave3_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave3_tilemap)
extern const unsigned char bg_cave3_tilemap[];

#endif
