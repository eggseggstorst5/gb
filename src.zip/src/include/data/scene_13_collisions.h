#ifndef SCENE_13_COLLISIONS_H
#define SCENE_13_COLLISIONS_H

// Scene: Scene 13
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_13_collisions)
extern const unsigned char scene_13_collisions[];

#endif
