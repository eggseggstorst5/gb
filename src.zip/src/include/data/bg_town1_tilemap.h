#ifndef BG_TOWN1_TILEMAP_H
#define BG_TOWN1_TILEMAP_H

// Tilemap bg_town1_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_town1_tilemap)
extern const unsigned char bg_town1_tilemap[];

#endif
