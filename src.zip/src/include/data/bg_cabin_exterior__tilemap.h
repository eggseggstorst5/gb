#ifndef BG_CABIN_EXTERIOR__TILEMAP_H
#define BG_CABIN_EXTERIOR__TILEMAP_H

// Tilemap bg_cabin_exterior__tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_cabin_exterior__tilemap)
extern const unsigned char bg_cabin_exterior__tilemap[];

#endif
