#ifndef BG_CABIN_EXTERIOR__H
#define BG_CABIN_EXTERIOR__H

// Background: Cabin(Exterior)

#include "gbs_types.h"

BANKREF_EXTERN(bg_cabin_exterior_)
extern const struct background_t bg_cabin_exterior_;

#endif
