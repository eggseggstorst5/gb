#ifndef BG_STARTMAP_TILESET_H
#define BG_STARTMAP_TILESET_H

// Tileset: bg_startmap_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_startmap_tileset)
extern const struct tileset_t bg_startmap_tileset;

#endif
