#ifndef SCENE_7_TRIGGERS_H
#define SCENE_7_TRIGGERS_H

// Scene: Scene 7
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_7_triggers)
extern const struct trigger_t scene_7_triggers[];

#endif
