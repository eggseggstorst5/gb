#ifndef SCENE_3_INIT_H
#define SCENE_3_INIT_H

// Script scene_3_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_3_init)
extern const unsigned char scene_3_init[];

#endif
