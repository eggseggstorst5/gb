#ifndef SCENE_15_H
#define SCENE_15_H

// Scene: Scene 15

#include "gbs_types.h"

BANKREF_EXTERN(scene_15)
extern const struct scene_t scene_15;

#endif
