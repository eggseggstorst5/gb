#ifndef SCENE_4_INIT_H
#define SCENE_4_INIT_H

// Script scene_4_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_4_init)
extern const unsigned char scene_4_init[];

#endif
