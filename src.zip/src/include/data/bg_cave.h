#ifndef BG_CAVE_H
#define BG_CAVE_H

// Background: cave

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave)
extern const struct background_t bg_cave;

#endif
