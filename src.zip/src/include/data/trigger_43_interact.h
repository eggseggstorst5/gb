#ifndef TRIGGER_43_INTERACT_H
#define TRIGGER_43_INTERACT_H

// Script trigger_43_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_43_interact)
extern const unsigned char trigger_43_interact[];

#endif
