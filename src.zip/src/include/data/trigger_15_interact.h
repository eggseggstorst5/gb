#ifndef TRIGGER_15_INTERACT_H
#define TRIGGER_15_INTERACT_H

// Script trigger_15_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_15_interact)
extern const unsigned char trigger_15_interact[];

#endif
