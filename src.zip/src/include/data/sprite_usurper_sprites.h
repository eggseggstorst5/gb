#ifndef SPRITE_USURPER_SPRITES_H
#define SPRITE_USURPER_SPRITES_H

// SpriteSheet: usurper-sprites

#include "gbs_types.h"

BANKREF_EXTERN(sprite_usurper_sprites)
extern const struct spritesheet_t sprite_usurper_sprites;

#endif
