#ifndef SCRIPT_INIT_MENU_H
#define SCRIPT_INIT_MENU_H

// Script script_init_menu

#include "gbs_types.h"

BANKREF_EXTERN(script_init_menu)
extern const unsigned char script_init_menu[];

#endif
