#ifndef BG_MAAAAPP_TILEMAP_H
#define BG_MAAAAPP_TILEMAP_H

// Tilemap bg_maaaapp_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_maaaapp_tilemap)
extern const unsigned char bg_maaaapp_tilemap[];

#endif
