#ifndef SCENE_21_H
#define SCENE_21_H

// Scene: Scene 21

#include "gbs_types.h"

BANKREF_EXTERN(scene_21)
extern const struct scene_t scene_21;

#endif
