#ifndef SCENE_10_TRIGGERS_H
#define SCENE_10_TRIGGERS_H

// Scene: Scene 10
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_10_triggers)
extern const struct trigger_t scene_10_triggers[];

#endif
