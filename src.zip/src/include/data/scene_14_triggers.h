#ifndef SCENE_14_TRIGGERS_H
#define SCENE_14_TRIGGERS_H

// Scene: Scene 14
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_14_triggers)
extern const struct trigger_t scene_14_triggers[];

#endif
