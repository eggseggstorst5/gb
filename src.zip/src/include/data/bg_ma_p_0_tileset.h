#ifndef BG_MA_P_0_TILESET_H
#define BG_MA_P_0_TILESET_H

// Tileset: bg_ma_p_0_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_ma_p_0_tileset)
extern const struct tileset_t bg_ma_p_0_tileset;

#endif
