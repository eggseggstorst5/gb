#ifndef SPRITE_TORCH_H
#define SPRITE_TORCH_H

// SpriteSheet: torch

#include "gbs_types.h"

BANKREF_EXTERN(sprite_torch)
extern const struct spritesheet_t sprite_torch;

#endif
