#ifndef TRIGGER_1_INTERACT_H
#define TRIGGER_1_INTERACT_H

// Script trigger_1_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_1_interact)
extern const unsigned char trigger_1_interact[];

#endif
