#ifndef SPRITE_NPC001_TILESET_H
#define SPRITE_NPC001_TILESET_H

// Tileset: sprite_npc001_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc001_tileset)
extern const struct tileset_t sprite_npc001_tileset;

#endif
