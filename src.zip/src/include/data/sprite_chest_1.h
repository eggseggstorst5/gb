#ifndef SPRITE_CHEST_1_H
#define SPRITE_CHEST_1_H

// SpriteSheet: Chest_1

#include "gbs_types.h"

BANKREF_EXTERN(sprite_chest_1)
extern const struct spritesheet_t sprite_chest_1;

#endif
