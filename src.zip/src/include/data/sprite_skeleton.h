#ifndef SPRITE_SKELETON_H
#define SPRITE_SKELETON_H

// SpriteSheet: skeleton

#include "gbs_types.h"

BANKREF_EXTERN(sprite_skeleton)
extern const struct spritesheet_t sprite_skeleton;

#endif
