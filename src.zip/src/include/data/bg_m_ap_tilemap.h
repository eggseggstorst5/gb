#ifndef BG_M_AP_TILEMAP_H
#define BG_M_AP_TILEMAP_H

// Tilemap bg_m_ap_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_m_ap_tilemap)
extern const unsigned char bg_m_ap_tilemap[];

#endif
