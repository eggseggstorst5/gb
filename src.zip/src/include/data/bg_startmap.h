#ifndef BG_STARTMAP_H
#define BG_STARTMAP_H

// Background: startmap

#include "gbs_types.h"

BANKREF_EXTERN(bg_startmap)
extern const struct background_t bg_startmap;

#endif
