#ifndef TRIGGER_24_INTERACT_H
#define TRIGGER_24_INTERACT_H

// Script trigger_24_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_24_interact)
extern const unsigned char trigger_24_interact[];

#endif
