#ifndef SCENE_14_SPRITES_H
#define SCENE_14_SPRITES_H

// Scene: Scene 14
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_14_sprites)
extern const far_ptr_t scene_14_sprites[];

#endif
