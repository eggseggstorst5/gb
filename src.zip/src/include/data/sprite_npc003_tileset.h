#ifndef SPRITE_NPC003_TILESET_H
#define SPRITE_NPC003_TILESET_H

// Tileset: sprite_npc003_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc003_tileset)
extern const struct tileset_t sprite_npc003_tileset;

#endif
