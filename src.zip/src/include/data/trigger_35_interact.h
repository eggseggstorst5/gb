#ifndef TRIGGER_35_INTERACT_H
#define TRIGGER_35_INTERACT_H

// Script trigger_35_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_35_interact)
extern const unsigned char trigger_35_interact[];

#endif
