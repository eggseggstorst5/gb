#ifndef SPRITE_USURPER_SPRITES_TILESET_H
#define SPRITE_USURPER_SPRITES_TILESET_H

// Tileset: sprite_usurper_sprites_tileset

#include "gbs_types.h"

BANKREF_EXTERN(sprite_usurper_sprites_tileset)
extern const struct tileset_t sprite_usurper_sprites_tileset;

#endif
