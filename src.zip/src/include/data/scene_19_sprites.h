#ifndef SCENE_19_SPRITES_H
#define SCENE_19_SPRITES_H

// Scene: Scene 19
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_19_sprites)
extern const far_ptr_t scene_19_sprites[];

#endif
