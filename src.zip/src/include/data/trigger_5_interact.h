#ifndef TRIGGER_5_INTERACT_H
#define TRIGGER_5_INTERACT_H

// Script trigger_5_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_5_interact)
extern const unsigned char trigger_5_interact[];

#endif
