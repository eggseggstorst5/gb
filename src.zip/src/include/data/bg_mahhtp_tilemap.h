#ifndef BG_MAHHTP_TILEMAP_H
#define BG_MAHHTP_TILEMAP_H

// Tilemap bg_mahhtp_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_mahhtp_tilemap)
extern const unsigned char bg_mahhtp_tilemap[];

#endif
