#ifndef SCENE_14_ACTORS_H
#define SCENE_14_ACTORS_H

// Scene: Scene 14
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_14_actors)
extern const struct actor_t scene_14_actors[];

#endif
