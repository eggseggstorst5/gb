#ifndef GAME_GLOBALS_H
#define GAME_GLOBALS_H

#define VAR_QUEST1 0
#define VAR_QUEST2 1
#define VAR_QUEST3 2
#define VAR_QUEST4 3
#define VAR_QUEST5 4
#define VAR_QUEST6 5
#define VAR_NEWGAME 6
#define VAR_VARIABLE_13 7
#define VAR_VARIABLE_14 8
#define VAR_VARIABLE_15 9
#define VAR_S7T1_LOCAL_0 10

#endif
