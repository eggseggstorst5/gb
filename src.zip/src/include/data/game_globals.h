#ifndef GAME_GLOBALS_H
#define GAME_GLOBALS_H

#define VAR_QUEST1 0
#define VAR_QUEST2 1
#define VAR_QUEST3 2
#define VAR_QUEST4 3
#define VAR_QUEST5 4
#define VAR_QUEST6 5
#define VAR_NEWGAME 6
#define VAR_S7T1_LOCAL_0 7
#define VAR_S11T4_LOCAL_0 8

#endif
