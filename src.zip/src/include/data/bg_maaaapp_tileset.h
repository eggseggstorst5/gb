#ifndef BG_MAAAAPP_TILESET_H
#define BG_MAAAAPP_TILESET_H

// Tileset: bg_maaaapp_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_maaaapp_tileset)
extern const struct tileset_t bg_maaaapp_tileset;

#endif
