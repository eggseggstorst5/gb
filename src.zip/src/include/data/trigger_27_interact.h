#ifndef TRIGGER_27_INTERACT_H
#define TRIGGER_27_INTERACT_H

// Script trigger_27_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_27_interact)
extern const unsigned char trigger_27_interact[];

#endif
