#ifndef SPRITE_NPC001_H
#define SPRITE_NPC001_H

// SpriteSheet: npc001

#include "gbs_types.h"

BANKREF_EXTERN(sprite_npc001)
extern const struct spritesheet_t sprite_npc001;

#endif
