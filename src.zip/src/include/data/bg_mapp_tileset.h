#ifndef BG_MAPP_TILESET_H
#define BG_MAPP_TILESET_H

// Tileset: bg_mapp_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_mapp_tileset)
extern const struct tileset_t bg_mapp_tileset;

#endif
