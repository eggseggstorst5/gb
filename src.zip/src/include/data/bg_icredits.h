#ifndef BG_ICREDITS_H
#define BG_ICREDITS_H

// Background: icredits

#include "gbs_types.h"

BANKREF_EXTERN(bg_icredits)
extern const struct background_t bg_icredits;

#endif
