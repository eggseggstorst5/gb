#ifndef BG_MFORESTSTARTP_H
#define BG_MFORESTSTARTP_H

// Background: mforeststartp

#include "gbs_types.h"

BANKREF_EXTERN(bg_mforeststartp)
extern const struct background_t bg_mforeststartp;

#endif
