#ifndef SCENE_14_H
#define SCENE_14_H

// Scene: Scene 14

#include "gbs_types.h"

BANKREF_EXTERN(scene_14)
extern const struct scene_t scene_14;

#endif
