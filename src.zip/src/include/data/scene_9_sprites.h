#ifndef SCENE_9_SPRITES_H
#define SCENE_9_SPRITES_H

// Scene: Scene 9
// Sprites

#include "gbs_types.h"

BANKREF_EXTERN(scene_9_sprites)
extern const far_ptr_t scene_9_sprites[];

#endif
