#ifndef BG_MAPP_TILEMAP_H
#define BG_MAPP_TILEMAP_H

// Tilemap bg_mapp_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_mapp_tilemap)
extern const unsigned char bg_mapp_tilemap[];

#endif
