#ifndef TRIGGER_40_INTERACT_H
#define TRIGGER_40_INTERACT_H

// Script trigger_40_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_40_interact)
extern const unsigned char trigger_40_interact[];

#endif
