#ifndef BG_UNTITLED_H
#define BG_UNTITLED_H

// Background: Untitled

#include "gbs_types.h"

BANKREF_EXTERN(bg_untitled)
extern const struct background_t bg_untitled;

#endif
