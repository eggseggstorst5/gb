#ifndef SCENE_12_H
#define SCENE_12_H

// Scene: Scene 12

#include "gbs_types.h"

BANKREF_EXTERN(scene_12)
extern const struct scene_t scene_12;

#endif
