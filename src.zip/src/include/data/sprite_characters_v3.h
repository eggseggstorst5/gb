#ifndef SPRITE_CHARACTERS_V3_H
#define SPRITE_CHARACTERS_V3_H

// SpriteSheet: Characters_V3

#include "gbs_types.h"

BANKREF_EXTERN(sprite_characters_v3)
extern const struct spritesheet_t sprite_characters_v3;

#endif
