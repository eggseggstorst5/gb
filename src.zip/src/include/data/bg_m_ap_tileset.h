#ifndef BG_M_AP_TILESET_H
#define BG_M_AP_TILESET_H

// Tileset: bg_m_ap_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_m_ap_tileset)
extern const struct tileset_t bg_m_ap_tileset;

#endif
