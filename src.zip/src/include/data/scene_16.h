#ifndef SCENE_16_H
#define SCENE_16_H

// Scene: Scene 16

#include "gbs_types.h"

BANKREF_EXTERN(scene_16)
extern const struct scene_t scene_16;

#endif
