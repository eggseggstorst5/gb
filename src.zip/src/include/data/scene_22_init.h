#ifndef SCENE_22_INIT_H
#define SCENE_22_INIT_H

// Script scene_22_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_22_init)
extern const unsigned char scene_22_init[];

#endif
