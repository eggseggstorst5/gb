#ifndef BG_CAVE2_TILEMAP_H
#define BG_CAVE2_TILEMAP_H

// Tilemap bg_cave2_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave2_tilemap)
extern const unsigned char bg_cave2_tilemap[];

#endif
