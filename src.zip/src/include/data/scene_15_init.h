#ifndef SCENE_15_INIT_H
#define SCENE_15_INIT_H

// Script scene_15_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_15_init)
extern const unsigned char scene_15_init[];

#endif
