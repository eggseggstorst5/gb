#ifndef TRIGGER_31_INTERACT_H
#define TRIGGER_31_INTERACT_H

// Script trigger_31_interact

#include "gbs_types.h"

BANKREF_EXTERN(trigger_31_interact)
extern const unsigned char trigger_31_interact[];

#endif
