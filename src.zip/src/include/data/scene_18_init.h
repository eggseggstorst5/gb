#ifndef SCENE_18_INIT_H
#define SCENE_18_INIT_H

// Script scene_18_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_18_init)
extern const unsigned char scene_18_init[];

#endif
