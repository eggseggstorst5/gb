#ifndef BG_TOWN2_TILEMAP_H
#define BG_TOWN2_TILEMAP_H

// Tilemap bg_town2_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_town2_tilemap)
extern const unsigned char bg_town2_tilemap[];

#endif
