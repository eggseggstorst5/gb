#ifndef SCENE_13_H
#define SCENE_13_H

// Scene: Scene 13

#include "gbs_types.h"

BANKREF_EXTERN(scene_13)
extern const struct scene_t scene_13;

#endif
