#ifndef SCENE_22_ACTORS_H
#define SCENE_22_ACTORS_H

// Scene: Scene 22
// Actors

#include "gbs_types.h"

BANKREF_EXTERN(scene_22_actors)
extern const struct actor_t scene_22_actors[];

#endif
