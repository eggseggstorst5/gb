#ifndef BG_ICREDITS_TILEMAP_H
#define BG_ICREDITS_TILEMAP_H

// Tilemap bg_icredits_tilemap

#include "gbs_types.h"

BANKREF_EXTERN(bg_icredits_tilemap)
extern const unsigned char bg_icredits_tilemap[];

#endif
