#ifndef SCENE_16_INIT_H
#define SCENE_16_INIT_H

// Script scene_16_init

#include "gbs_types.h"

BANKREF_EXTERN(scene_16_init)
extern const unsigned char scene_16_init[];

#endif
