#ifndef SCENE_6_COLLISIONS_H
#define SCENE_6_COLLISIONS_H

// Scene: Scene 6
// Collisions

#include "gbs_types.h"

BANKREF_EXTERN(scene_6_collisions)
extern const unsigned char scene_6_collisions[];

#endif
