#ifndef SCENE_21_TRIGGERS_H
#define SCENE_21_TRIGGERS_H

// Scene: Scene 21
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_21_triggers)
extern const struct trigger_t scene_21_triggers[];

#endif
