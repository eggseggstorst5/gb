#ifndef BG_CAVE3_H
#define BG_CAVE3_H

// Background: cave3

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave3)
extern const struct background_t bg_cave3;

#endif
