#ifndef BG_MAHHTP_TILESET_H
#define BG_MAHHTP_TILESET_H

// Tileset: bg_mahhtp_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_mahhtp_tileset)
extern const struct tileset_t bg_mahhtp_tileset;

#endif
