#ifndef BG_CAVE2_TILESET_H
#define BG_CAVE2_TILESET_H

// Tileset: bg_cave2_tileset

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave2_tileset)
extern const struct tileset_t bg_cave2_tileset;

#endif
