#ifndef SCENE_22_TRIGGERS_H
#define SCENE_22_TRIGGERS_H

// Scene: Scene 22
// Triggers

#include "gbs_types.h"

BANKREF_EXTERN(scene_22_triggers)
extern const struct trigger_t scene_22_triggers[];

#endif
