#ifndef BG_CAVE2_H
#define BG_CAVE2_H

// Background: cave2

#include "gbs_types.h"

BANKREF_EXTERN(bg_cave2)
extern const struct background_t bg_cave2;

#endif
